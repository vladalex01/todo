import React from 'react';
import Article from '../template/Functions';
import Toggle from '../template/Functions'

class Home extends React.Component {

    render() {
        return (
            <Article>
                <h1><b>TITLE</b></h1>
                <p>Paragraph</p>
                <p>Paragraph</p>
                <p>Paragraph</p>
                <p>Paragraph</p>
                <p>Paragraph</p>
                <p>Paragraphs</p>
                <p>Paragraphs</p>
                <p>Paragraphs</p>
                <p>Paragraphs</p>
            </Article>
        );
    }
}


export default Home;