import React from 'react';
import Footer from '../template/Footer'
import Navbar from '../template/Navbar';
import Layout from '../template/Layout';

class Home extends React.Component {
    render() {
        return (
            <React.Fragment>
                <h1>Error 404! Page does not exist!</h1>
            </React.Fragment>
        );
    }
}

export default Home